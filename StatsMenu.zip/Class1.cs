﻿using System.Collections;
using BepInEx;
using BepInEx.Configuration;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

// Main plugin declaration for BepInEx
[BepInPlugin("com.recks.playerstatscanvas", "Player Stats Canvas GUI", "5.0.2")]
[BepInProcess("Erenshor.exe")]
public class PlayerStatsCanvasPlugin : BaseUnityPlugin
{
    // Core UI references
    private Canvas statsCanvas;              // The root Canvas for all UI
    private RectTransform panelRect;         // RectTransform of the main panel
    private GameObject windowPanel;          // Container for the panel background
    private GameObject headerObject;         // The top header bar
    private GameObject tabContainer;         // Holds the Stats/Reputation tab buttons
    private GameObject contentObject;        // Holds the dynamic text content
    private GameObject dragHandle;           // Drag handle (diamond) for moving the panel

    // Tab buttons and their images for highlighting
    private Button statsTab;
    private Button repTab;
    private Image statsTabImage;
    private Image repTabImage;

    // CanvasGroup for fade-in/out
    private CanvasGroup panelGroup;

    // State tracking
    private bool isLoaded;
    private bool dragging;
    private Vector2 dragOffset;

    // Configurable keys and colors
    private ConfigEntry<KeyCode> toggleKey;
    private ConfigEntry<Color> activeTabColor;
    private ConfigEntry<Color> inactiveTabColor;

    /// <summary>
    /// Called when plugin is loaded. Binds config entries.
    /// </summary>
    private void Awake()
    {
        // Key to toggle the UI
        toggleKey = Config.Bind("Controls", "ToggleKey", KeyCode.P, "Key to open/close the stats window");
        // Tab highlight colors
        activeTabColor = Config.Bind("Appearance", "ActiveTabColor", new Color(0.35f, 0.59f, 1f), "Color for active tab");
        inactiveTabColor = Config.Bind("Appearance", "InactiveTabColor", new Color(0.7f, 0.7f, 0.7f), "Color for inactive tab");
    }

    /// <summary>
    /// Per-frame update: checks for player load, toggles UI on key press.
    /// </summary>
    private void Update()
    {
        // Do nothing on the loading scene
        if (SceneManager.GetActiveScene().name == "LoadScene")
            return;

        // Once GameData.PlayerControl/Stats exist, initialize the UI
        if (!isLoaded && GameData.PlayerControl != null && GameData.PlayerStats != null)
        {
            isLoaded = true;
            InitializeUI();
        }
        if (!isLoaded)
            return;

        // Toggle panel visibility on key press
        if (Input.GetKeyDown(toggleKey.Value))
            TogglePanel();
    }

    /// <summary>
    /// Builds and configures all UI elements: canvas, panel, header, tabs, and content area.
    /// </summary>
    private void InitializeUI()
    {
        // 1. Create root Canvas
        var canvasGO = new GameObject("PlayerStatsCanvas");
        statsCanvas = canvasGO.AddComponent<Canvas>();
        statsCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGO.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        canvasGO.AddComponent<GraphicRaycaster>();
        DontDestroyOnLoad(canvasGO);

        // 2. Create panel container under Canvas
        windowPanel = new GameObject("WindowPanel");
        windowPanel.transform.SetParent(canvasGO.transform, false);
        panelRect = windowPanel.AddComponent<RectTransform>();
        panelRect.sizeDelta = new Vector2(420, 620);
        panelRect.anchoredPosition = Vector2.zero;

        // 3. Add background image (with optional rounded sprite)
        var bg = windowPanel.AddComponent<Image>();
        Sprite spr = null;
        try { spr = Resources.GetBuiltinResource<Sprite>("UI/Skin/UISprite.psd"); } catch { spr = null; }
        if (spr != null)
        {
            bg.sprite = spr;
            bg.type = Image.Type.Sliced;
        }
        else
        {
            bg.type = Image.Type.Simple;
        }
        bg.color = new Color32(20, 30, 45, 230);
        windowPanel.AddComponent<Shadow>().effectColor = new Color(0, 0, 0, 0.5f);

        // 4. CanvasGroup for fade animations
        panelGroup = windowPanel.AddComponent<CanvasGroup>();
        panelGroup.alpha = 0f;
        panelGroup.interactable = false;
        panelGroup.blocksRaycasts = false;

        // 5. Header bar setup
        headerObject = new GameObject("Header");
        headerObject.transform.SetParent(windowPanel.transform, false);
        var hdrRect = headerObject.AddComponent<RectTransform>();
        hdrRect.anchorMin = new Vector2(0, 1);
        hdrRect.anchorMax = new Vector2(1, 1);
        hdrRect.pivot = new Vector2(0.5f, 1);
        hdrRect.anchoredPosition = Vector2.zero;
        hdrRect.sizeDelta = new Vector2(0, 40);
        var hdrImg = headerObject.AddComponent<Image>();
        hdrImg.color = new Color32(18, 30, 45, 255);
        var title = CreateText(headerObject.transform, "Player Stats & Reputation", 22, TextAnchor.MiddleCenter);
        title.rectTransform.anchorMin = Vector2.zero;
        title.rectTransform.anchorMax = Vector2.one;

        // 6. Drag handle for moving the panel
        dragHandle = new GameObject("DragHandle");
        dragHandle.transform.SetParent(headerObject.transform, false);
        var dragRect = dragHandle.AddComponent<RectTransform>();
        dragRect.anchorMin = dragRect.anchorMax = new Vector2(1, 1);
        dragRect.pivot = new Vector2(1, 1);
        dragRect.anchoredPosition = new Vector2(-20, -10); // padded right
        dragRect.sizeDelta = new Vector2(16, 16);
        var dragImg = dragHandle.AddComponent<Image>();
        dragImg.color = new Color32(108, 194, 255, 255);
        dragHandle.transform.rotation = Quaternion.Euler(0, 0, 45);
        AddDragEvents(dragHandle.AddComponent<EventTrigger>());

        // 7. Tab buttons container
        tabContainer = new GameObject("Tabs");
        tabContainer.transform.SetParent(windowPanel.transform, false);
        var tabsRect = tabContainer.AddComponent<RectTransform>();
        tabsRect.anchorMin = new Vector2(0, 1);
        tabsRect.anchorMax = new Vector2(1, 1);
        tabsRect.pivot = new Vector2(0.5f, 1);
        tabsRect.anchoredPosition = new Vector2(0, -40);
        tabsRect.sizeDelta = new Vector2(0, 32);
        var hlg = tabContainer.AddComponent<HorizontalLayoutGroup>();
        hlg.childAlignment = TextAnchor.MiddleCenter;
        hlg.spacing = 12;

        // Create Stats & Reputation tabs
        statsTab = CreateTabButton("Stats");
        statsTab.onClick.AddListener(() => ShowStats(true));
        statsTabImage = statsTab.GetComponent<Image>();
        repTab = CreateTabButton("Reputation");
        repTab.onClick.AddListener(() => ShowStats(false));
        repTabImage = repTab.GetComponent<Image>();

        // 8. Content area holds dynamic stats/reputation lines
        contentObject = new GameObject("Content");
        contentObject.transform.SetParent(windowPanel.transform, false);
        var ct = contentObject.AddComponent<RectTransform>();
        ct.anchorMin = new Vector2(0, 0);
        ct.anchorMax = new Vector2(1, 1);
        ct.anchoredPosition = Vector2.zero;
        ct.offsetMin = new Vector2(12, 12);
        ct.offsetMax = new Vector2(-12, -84);
        var layout = contentObject.AddComponent<VerticalLayoutGroup>();
        layout.childAlignment = TextAnchor.UpperLeft;
        layout.spacing = 6;
        layout.padding = new RectOffset(8, 8, 8, 8);
        layout.childForceExpandWidth = true;
        layout.childForceExpandHeight = false;

        // 9. Initial state setup
        ShowStats(true);
        HighlightTab(true);
        windowPanel.SetActive(false);
    }

    /// <summary>
    /// Creates a tab button with tinted transition.
    /// </summary>
    private Button CreateTabButton(string label)
    {
        var go = new GameObject(label + "Tab");
        go.transform.SetParent(tabContainer.transform, false);
        var rt = go.AddComponent<RectTransform>();
        rt.sizeDelta = new Vector2(120, 32);
        var img = go.AddComponent<Image>();
        img.color = inactiveTabColor.Value;
        var btn = go.AddComponent<Button>();
        btn.transition = Selectable.Transition.ColorTint;
        btn.colors = new ColorBlock
        {
            normalColor = inactiveTabColor.Value,
            highlightedColor = inactiveTabColor.Value * 1.2f,
            pressedColor = inactiveTabColor.Value * 0.9f,
            selectedColor = inactiveTabColor.Value,
            colorMultiplier = 1,
            fadeDuration = 0.1f
        };
        CreateText(go.transform, label, 18, TextAnchor.MiddleCenter);
        return btn;
    }

    /// <summary>
    /// Helper to create a Text UI element.
    /// </summary>
    private Text CreateText(Transform parent, string txtValue, int size, TextAnchor align)
    {
        var go = new GameObject("Text");
        go.transform.SetParent(parent, false);
        var t = go.AddComponent<Text>();
        t.text = txtValue;
        t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        t.fontSize = size;
        t.alignment = align;
        t.color = Color.white;
        go.AddComponent<Shadow>().effectColor = new Color(0, 0, 0, 0.5f);
        return t;
    }

    /// <summary>
    /// Toggles panel visibility with fade animations.
    /// </summary>
    private void TogglePanel()
    {
        if (!windowPanel.activeSelf)
            StartCoroutine(FadeIn());
        else
            StartCoroutine(FadeOut());
    }

    private IEnumerator FadeIn()
    {
        windowPanel.SetActive(true);
        panelGroup.interactable = false;
        panelGroup.blocksRaycasts = false;
        for (float t = 0; t < 1; t += Time.deltaTime * 2)
        {
            panelGroup.alpha = t;
            yield return null;
        }
        panelGroup.alpha = 1;
        panelGroup.interactable = true;
        panelGroup.blocksRaycasts = true;
    }

    private IEnumerator FadeOut()
    {
        panelGroup.interactable = false;
        panelGroup.blocksRaycasts = false;
        for (float t = 1; t > 0; t -= Time.deltaTime * 2)
        {
            panelGroup.alpha = t;
            yield return null;
        }
        panelGroup.alpha = 0;
        windowPanel.SetActive(false);
    }

    /// <summary>
    /// Clears and repopulates content with stats or reputation.
    /// </summary>
    private void ShowStats(bool showStats)
    {
        // Clear existing lines
        foreach (Transform child in contentObject.transform)
            Destroy(child.gameObject);

        // Populate
        if (showStats)
            RefreshStats();
        else
            RefreshReputation();

        // Highlight the active tab
        HighlightTab(showStats);
    }

    /// <summary>
    /// Updates tab image colors based on active tab.
    /// </summary>
    private void HighlightTab(bool statsActive)
    {
        statsTabImage.color = statsActive ? activeTabColor.Value : inactiveTabColor.Value;
        repTabImage.color = statsActive ? inactiveTabColor.Value : activeTabColor.Value;
    }

    /// <summary>
    /// Gathers player stats and adds lines to the UI.
    /// </summary>
    private void RefreshStats()
    {
        var s = GameData.PlayerStats;
        var inv = s.MyInv;
        AddLine($"Level: {s.Level}");
        AddLine($"Strength: {s.GetCurrentStr()} (+{inv.ItemStr})");
        AddLine($"Dexterity: {s.GetCurrentDex()} (+{inv.ItemDex})");
        AddLine($"Endurance: {s.GetCurrentEnd()} (+{inv.ItemEnd})");
        AddLine($"Agility: {s.GetCurrentAgi()} (+{inv.ItemAgi})");
        AddLine($"Intelligence: {s.GetCurrentInt()} (+{inv.ItemInt})");
        AddLine($"Wisdom: {s.GetCurrentWis()} (+{inv.ItemWis})");
        AddLine($"Charisma: {s.GetCurrentCha()} (+{inv.ItemCha})");
        AddLine($"Damage Bonus: +{s.GetCurrentInt()}");
        AddLine($"Healing Bonus: +{s.GetCurrentWis()}");
        float crit = s.GetCurrentDex() * 0.25f;
        float dodge = s.GetCurrentAgi() * 0.20f;
        AddLine($"Crit Chance: {crit:F1}%");
        AddLine($"Dodge Chance: {dodge:F1}%");
    }

    /// <summary>
    /// Gathers faction reputations and adds lines to the UI.
    /// </summary>
    private void RefreshReputation()
    {
        foreach (var f in GlobalFactionManager.AllFactions)
            AddLine($"{f.Desc}: {f.Value:F1}");
    }

    /// <summary>
    /// Instantiates a line of text under the content container.
    /// </summary>
    private void AddLine(string text)
    {
        var go = new GameObject("Line");
        go.transform.SetParent(contentObject.transform, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(0, 1);
        rt.anchorMax = new Vector2(1, 1);
        rt.pivot = new Vector2(0.5f, 1);
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = new Vector2(0, 24); // fixed line height

        var t = go.AddComponent<Text>();
        t.text = text;
        t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        t.fontSize = 16;
        t.alignment = TextAnchor.MiddleLeft;
        t.color = Color.white;
        go.AddComponent<Shadow>().effectColor = new Color(0, 0, 0, 0.5f);
    }

    /// <summary>
    /// Adds drag functionality to the diamond handle.
    /// </summary>
    private void AddDragEvents(EventTrigger et)
    {
        // Begin drag
        var eb = new EventTrigger.Entry { eventID = EventTriggerType.BeginDrag };
        eb.callback.AddListener(data => {
            dragging = true;
            var ped = (PointerEventData)data;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(panelRect, ped.position, null, out dragOffset);
        });

        // During drag
        var ed = new EventTrigger.Entry { eventID = EventTriggerType.Drag };
        ed.callback.AddListener(data => {
            if (dragging)
            {
                var ped = (PointerEventData)data;
                Vector2 pos;
                RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    statsCanvas.transform as RectTransform, ped.position, null, out pos);
                panelRect.anchoredPosition = pos - dragOffset;
            }
        });

        // End drag
        var ee = new EventTrigger.Entry { eventID = EventTriggerType.EndDrag };
        ee.callback.AddListener(data => { dragging = false; });

        // Register entries
        et.triggers.Add(eb);
        et.triggers.Add(ed);
        et.triggers.Add(ee);
    }
}
